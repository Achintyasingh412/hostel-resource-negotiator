import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { AuthForm } from "@/components/auth-form";
import { getDemoSession } from "@/lib/demo-session";
import { getDemoUsers } from "@/lib/demo-users";

export const metadata: Metadata = { title: "Sign in · Hostel Nexus" };
export const dynamic = "force-dynamic";

export default async function SignInPage() {
  const session = await getDemoSession();
  if (session) redirect("/");
  return <AuthForm accounts={getDemoUsers()} />;
}
