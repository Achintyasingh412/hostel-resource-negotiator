import type { Metadata } from "next";
import { redirect } from "next/navigation";

export const metadata: Metadata = { title: "Sign in · Hostel Nexus" };

export default function SignUpPage() {
  redirect("/sign-in");
}
