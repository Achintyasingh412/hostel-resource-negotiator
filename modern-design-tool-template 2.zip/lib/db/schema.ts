import {
  date,
  index,
  integer,
  pgTable,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export const hostelProfiles = pgTable("hostel_profiles", {
  userId: text("user_id").primaryKey().notNull(),
  hostelUid: text("hostel_uid").unique().notNull(),
  credits: integer("credits").notNull().default(4),
  weekStart: date("week_start", { mode: "string" }).notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const resourceBookings = pgTable(
  "resource_bookings",
  {
    id: text("id").primaryKey().notNull(),
    communityId: text("community_id").notNull().default("wing-4b"),
    userId: text("user_id").notNull(),
    userName: text("user_name").notNull(),
    resource: text("resource").notNull(),
    slot: text("slot").notNull(),
    bookingDate: date("booking_date", { mode: "string" }).notNull(),
    bookedAt: timestamp("booked_at", { withTimezone: true }).notNull().defaultNow(),
    wardenNote: text("warden_note").notNull().default(""),
    status: text("status").notNull().default("ACTIVE"),
    cancelledAt: timestamp("cancelled_at", { withTimezone: true }),
  },
  (table) => ({
    communityDateIndex: index("resource_bookings_community_date_idx").on(
      table.communityId,
      table.bookingDate,
      table.slot,
    ),
    userBookingsIndex: index("resource_bookings_user_idx").on(
      table.userId,
      table.bookedAt,
    ),
  }),
);

export const wardenLog = pgTable(
  "warden_log",
  {
    id: text("id").primaryKey().notNull(),
    communityId: text("community_id").notNull().default("wing-4b"),
    event: text("event").notNull(),
    actorUserId: text("actor_user_id").notNull(),
    actorName: text("actor_name").notNull(),
    resource: text("resource").notNull(),
    slot: text("slot").notNull(),
    bookingDate: date("booking_date", { mode: "string" }).notNull(),
    note: text("note").notNull().default(""),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    communityCreatedIndex: index("warden_log_community_created_idx").on(
      table.communityId,
      table.createdAt,
    ),
  }),
);
